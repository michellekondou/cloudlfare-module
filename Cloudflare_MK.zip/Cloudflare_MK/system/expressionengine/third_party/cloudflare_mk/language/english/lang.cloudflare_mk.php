<?php
$lang = array(

'cloudflare_mk_module_name' 		=> 'CloudFlare MK',
'cloudflare_mk_module_description' 	=> 'CloudFlare MK Remote Admin',

//
''=>''
);